-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2024 at 07:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Mohamed S Bah', 'dcorrectman.official@gmail.com', 'dcorrectman', 'f925916e2754e5e03f75dd58a5733251', '2024-01-23 10:08:41'),
(2, 'SILVA BAH', 'correctmanofficial@gmail.com', 'silvabah', 'f925916e2754e5e03f75dd58a5733251', '2024-01-23 10:08:41');

-- --------------------------------------------------------

--
-- Table structure for table `tblauthors`
--

CREATE TABLE `tblauthors` (
  `id` int(11) NOT NULL,
  `AuthorName` varchar(159) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblauthors`
--

INSERT INTO `tblauthors` (`id`, `AuthorName`, `creationDate`, `UpdationDate`) VALUES
(16, 'Robert T Kiyosaki', '2024-01-23 13:10:46', NULL),
(17, 'Kyle Hill ', '2024-01-23 13:10:58', NULL),
(18, 'Andreas Hellard | Vincent Maverick Durano | Jeffrey Chilbert | Ed Price', '2024-01-23 13:11:51', NULL),
(19, 'Alagar Rainanujam | Viday Arora', '2024-01-23 13:12:56', NULL),
(20, 'Joel Murach ', '2024-01-23 13:23:59', NULL),
(21, 'Herbert Schildt', '2024-01-23 13:24:26', NULL),
(22, 'Steven Holzner', '2024-01-23 13:24:51', NULL),
(23, 'Hal Elrod', '2024-01-23 13:25:04', NULL),
(24, 'Mike Mckever', '2024-01-23 13:25:19', NULL),
(25, 'Madsen Pirie', '2024-01-23 13:25:38', NULL),
(26, 'Bruce N. Waller', '2024-01-23 13:26:04', NULL),
(27, 'John C. Maxwell', '2024-01-23 13:26:23', NULL),
(28, 'Eliare Kurbegou', '2024-01-23 13:27:01', NULL),
(29, 'Peter Howarth', '2024-01-23 13:27:22', NULL),
(30, 'Adeel Javed', '2024-01-23 13:27:38', NULL),
(31, 'Barry Burd', '2024-01-23 13:27:52', NULL),
(32, 'Dr Andy Williams', '2024-01-23 13:28:09', NULL),
(33, 'Mel Robbins', '2024-01-23 13:28:53', NULL),
(34, 'Thomas Mailund', '2024-01-23 13:44:55', NULL),
(35, 'Joan Lambert', '2024-01-23 13:46:25', NULL),
(36, 'Curtis Frye', '2024-01-23 13:50:49', NULL),
(37, 'Paul M Collier', '2024-01-23 13:58:39', NULL),
(38, 'Peter Weverka', '2024-01-23 14:19:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE `tblbooks` (
  `id` int(11) NOT NULL,
  `BookName` varchar(255) DEFAULT NULL,
  `CatId` int(11) DEFAULT NULL,
  `AuthorId` int(11) DEFAULT NULL,
  `ISBNNumber` varchar(25) DEFAULT NULL,
  `BookPrice` decimal(10,2) DEFAULT NULL,
  `bookImage` varchar(250) NOT NULL,
  `isIssued` int(1) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`id`, `BookName`, `CatId`, `AuthorId`, `ISBNNumber`, `BookPrice`, `bookImage`, `isIssued`, `RegDate`, `UpdationDate`) VALUES
(13, 'Rich Dad Poor Dad', 12, 16, '0446677051', 120.00, '945b4980125766a6e0dea1fd232ddcfd.jpg', NULL, '2024-01-23 13:32:40', NULL),
(15, 'WordPress for Beginners 2022', 10, 32, '00001', 200.00, 'f2eb9c522db53d1c24dbdb0107b24305.jpg', NULL, '2024-01-23 13:37:36', NULL),
(16, 'C++ - The Complete Reference', 10, 21, '00002', 200.00, 'de817bfd1d5eddc91b5477f8f10929f3.jpg', NULL, '2024-01-23 13:39:16', NULL),
(17, 'Murach\'s MySQL', 10, 20, '00003', 220.00, 'a78d89a3f8e23128ce6fc7fb2270f29d.jpg', NULL, '2024-01-23 13:40:40', NULL),
(18, 'WordPress Mastery Guide', 10, 17, '00004', 180.00, '2f47cb66743b2599a8aa80e918d7c765.jpg', NULL, '2024-01-23 13:42:04', NULL),
(19, 'ASP.net Core 5 for Beginners', 10, 18, '00005', 180.00, '226dfb988c1a5eeb24d18ca76997d776.jpg', NULL, '2024-01-23 13:43:26', NULL),
(20, 'Beginning Data Science in R', 10, 34, '00006', 150.00, '777933c6aa2266d3b0034669e3c4841a.jpg', NULL, '2024-01-23 13:45:49', NULL),
(21, 'Microsoft Word 2016', 14, 35, '00007', 120.00, 'bc9c33ebe2597a7ce88c0dfd886df44f.jpg', 1, '2024-01-23 13:48:58', '2024-02-23 13:15:51'),
(22, 'Microsoft PowerPoint 2016', 14, 35, '00008', 120.00, '5da031796ef629eff89defa1a33f73f9.jpg', 1, '2024-01-23 13:50:28', '2024-02-23 13:16:19'),
(23, 'Microsoft Excel 2016', 14, 36, '00009', 120.00, '4bd5c6ea5e9a6c1a6587ef808483faef.jpg', NULL, '2024-01-23 13:51:41', NULL),
(24, 'French Vocabulary', 13, 28, '00010', 130.00, 'e4d0143a8ad059950f438d1daa493822.jpg', NULL, '2024-01-23 13:53:01', NULL),
(25, 'How Successful People Think', 12, 27, '00011', 120.00, 'b79e0b073d2e1b8087231f119fbcc16d.jpg', NULL, '2024-01-23 13:54:07', NULL),
(26, 'PHP - The Complete Reference', 10, 22, '00012', 150.00, 'be735b14cd19a18c583ce34b47d7fd60.jpg', NULL, '2024-01-23 13:55:30', NULL),
(27, 'Beginning Programming with Java for Dummies', 10, 31, '00013', 170.00, '3dcbb078edff5884d4d46bde63f3b170.jpg', NULL, '2024-01-23 13:56:31', NULL),
(28, 'Building Arduino Project for the Internet of Things', 10, 30, '00014', 220.00, '0f190d9d4824b5536d3482765a110681.jpg', NULL, '2024-01-23 13:58:06', NULL),
(29, 'Accounting for Managers', 11, 37, '00015', 100.00, '81eefa9519cbfaf6fc660f22e6fbb408.jpg', NULL, '2024-01-23 13:59:16', NULL),
(30, 'Critical Thinking', 12, 26, '00016', 100.00, '590bbdedb27c7d8f12b94f22d79d2e16.jpg', NULL, '2024-01-23 14:00:17', NULL),
(31, 'How to Write a Business Plan', 11, 24, '00017', 100.00, 'f233df232aed92e90d20c392ca6e51d7.jpg', NULL, '2024-01-23 14:01:37', NULL),
(32, 'Microsoft Office 2019 - All in One', 14, 38, '00018', 180.00, '5c48414e0870402d5f8fccd469c7990e.jpg', NULL, '2024-01-23 14:21:24', NULL),
(33, 'Physics Redifined', 10, 19, '00019', 200.00, 'ce114212a8cea592d984d9277a6de31c.jpg', NULL, '2024-01-23 14:23:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(150) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Status`, `CreationDate`, `UpdationDate`) VALUES
(10, ' Computer Science', 1, '2024-01-23 12:28:47', '0000-00-00 00:00:00'),
(11, 'Business Administration', 1, '2024-01-23 12:29:03', '2024-01-23 13:10:19'),
(12, 'Self-Help', 1, '2024-01-23 12:29:16', '0000-00-00 00:00:00'),
(13, 'Language', 1, '2024-01-23 12:29:31', '0000-00-00 00:00:00'),
(14, 'IT Basics', 1, '2024-01-23 12:46:23', '2024-01-23 12:46:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblissuedbookdetails`
--

CREATE TABLE `tblissuedbookdetails` (
  `id` int(11) NOT NULL,
  `BookId` int(11) DEFAULT NULL,
  `StudentID` varchar(150) DEFAULT NULL,
  `IssuesDate` timestamp NULL DEFAULT current_timestamp(),
  `ReturnDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `RetrunStatus` int(1) DEFAULT NULL,
  `fine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblissuedbookdetails`
--

INSERT INTO `tblissuedbookdetails` (`id`, `BookId`, `StudentID`, `IssuesDate`, `ReturnDate`, `RetrunStatus`, `fine`) VALUES
(13, 21, 'SID016', '2024-02-23 13:15:51', NULL, NULL, NULL),
(14, 22, 'SID017', '2024-02-23 13:16:19', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL,
  `StudentId` varchar(100) DEFAULT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`id`, `StudentId`, `FullName`, `EmailId`, `MobileNumber`, `Password`, `Status`, `RegDate`, `UpdationDate`) VALUES
(12, 'SID001\r\n', 'Moses Tachequee', 'mosestquee@gmail.com', '031395253', 'ea289a07523076a5e470f4b30e3c39c2', 1, '2024-01-23 14:37:50', '2024-01-23 14:49:00'),
(17, 'SID002\r\n', 'Alusine Bangura', 'banguraa660@gmail.com', '033413507', 'b9aa42190f1e00d0d960c0b8b13cb4a1', 1, '2024-01-23 14:43:38', NULL),
(21, 'SID003	\r\n', 'Mohamed Bah', 'mohamedsbah.official@gmail.com', '034019311', '81dc9bdb52d04dc20036dbd8313ed055', 1, '2024-01-23 15:08:42', NULL),
(23, 'SID004\r\n', 'Gifty Ruth Sesay', 'zammiesesay@gmail.com', '072405809', 'a59b6b92b56a508d3d5e3f2ce9fbadf6', 1, '2024-01-23 15:17:27', NULL),
(25, 'SID016', 'Khadija Bah', 'khadijabah@gmail.com', '031482233', '81dc9bdb52d04dc20036dbd8313ed055', 1, '2024-02-23 13:12:40', NULL),
(26, 'SID017', 'Mabel Wilson', 'mabelwilson@gmail.com', '0310001123', '81dc9bdb52d04dc20036dbd8313ed055', 1, '2024-02-23 13:13:33', NULL),
(27, 'SID018', 'Saidu Kamara', 'tidowizzkamara@gmail.com', '+232779028', '21218cca77804d2ba1922c33e0151105', 1, '2024-02-27 17:31:18', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblauthors`
--
ALTER TABLE `tblauthors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooks`
--
ALTER TABLE `tblbooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissuedbookdetails`
--
ALTER TABLE `tblissuedbookdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `StudentId` (`StudentId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblauthors`
--
ALTER TABLE `tblauthors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tblbooks`
--
ALTER TABLE `tblbooks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblissuedbookdetails`
--
ALTER TABLE `tblissuedbookdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
